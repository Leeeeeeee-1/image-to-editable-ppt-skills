# Model selection and portability

This reference is deliberately capability-based. Model catalogs and prices change; verify the current catalog before deployment.

## Recommended stacks

### Codex/OpenAI host

| Mode | Reasoning/orchestration | Raster generation | Why |
|---|---|---|---|
| High-fidelity | GPT-5.6 Sol, or the current flagship multimodal reasoning model | GPT-Image-2.5 Sunburst, or the current highest-quality image model | Strongest layout interpretation and asset-generation headroom |
| Low-cost | GPT-5.6 Luna; use Terra when additional reasoning is worth the cost | None by default; generate adaptively when complex visuals cannot be reconstructed acceptably | Native geometry and deterministic coordinates do most of the work, but quality failures can trigger more asset generation |
| Balanced | GPT-5.6 Terra | Current image model only when an asset cannot be reconstructed locally | Middle ground for quality and cost |

The exact model IDs above are current recommendations, not a permanent requirement. If a host exposes only a different model family, select the strongest model that supports image input, tool/function calls, structured output and sufficient context. The model itself does not create editable PowerPoint semantics; the skill and PPTX builder do.

## External deployment requirements

An external host needs these interfaces:

1. Image input at sufficient resolution, preferably crop/zoom support and strong visual understanding of text, objects, layers and spatial relationships.
2. Structured JSON output for text boxes, object inventory, source-pixel boxes, z-order, confidence and unknown regions.
3. Optional image generation/editing or a segmentation backend for complex visual assets.
4. A deterministic PPTX writer using PresentationML/Open XML or an equivalent library.
5. A renderer and structural checker for visual and package-level QA.

### Gemini

Gemini is a strong external candidate for the analysis/segmentation stage. Google documents multimodal image input and capabilities including object detection and segmentation. It still needs a separate deterministic PPTX construction layer and a separate image-generation choice for high-fidelity assets.

### Claude

Claude is a strong candidate for visual reasoning, text extraction, planning and code orchestration. Its documented vision workflow supports image analysis. Inference: because that workflow is an image-input/analysis capability, a portable high-fidelity deployment should pair Claude with a separate image-generation backend unless the host supplies one.

## Decision rule

Recommend the Codex/OpenAI stack when the user wants one integrated workflow with ImageGen, local files, deterministic code and PPTX validation. Recommend Gemini when the deployment’s main bottleneck is visual parsing/segmentation and the team already has a PPTX builder. Recommend Claude when code orchestration and long-form planning are primary and an image backend is already available.

## Speed and concurrency guidance

- Analyze one rendered page with one multimodal call whenever possible; do not send every icon or picture object through a separate recognition call.
- Fan out independent pages and independent asset tasks, then join only at manifest assembly and final validation.
- For a one-page deck, page workers cannot create parallelism; the asset-task fan-out is the primary speed mechanism.
- Prefer deterministic crops, alpha cleanup and native geometry where they meet the selected fidelity target. For high-fidelity mode, generate every materially missing asset; use composite sheets or independent parallel jobs to reduce wall-clock time rather than limiting the number of calls.
- Set an explicit page and asset concurrency limit for rate control, not a total ImageGen budget. A slow asset should not block independent pages or assets; a failed asset may fall back only when the selected mode accepts that loss, otherwise continue with a changed generation attempt.

## Primary references

- OpenAI model catalog: https://developers.openai.com/api/docs/models
- Google Gemini image understanding: https://ai.google.dev/gemini-api/docs/image-understanding
- Anthropic vision: https://docs.anthropic.com/en/docs/build-with-claude/vision
- Microsoft Open XML presentation slides: https://learn.microsoft.com/en-us/office/open-xml/presentation/working-with-presentation-slides
