---
name: image-to-editable-ppt-dual-mode
description: Convert slide screenshots, scanned decks, or image-based PPT/PDF pages into editable PPTX with explicit high-fidelity or low-cost modes. Use GPT multimodal analysis, fixed source-pixel coordinates, optional image assets, usage tracking, and render/validate the result.
---

# Image-to-editable PPT dual mode

Use this skill when a user wants to make a slide image or image-based deck editable. The core workflow is GPT multimodal analysis plus fixed-coordinate PPTX reconstruction: readable text and layout structure become native objects, while complex visual assets may remain raster layers and must be disclosed.

## First interaction: require a mode choice

Before any external image-generation call or material output, ask one concise question unless the user already selected a mode:

> 请选择转换模式：
> 1. 高还原度：优先保持视觉相似度，按页面复杂度和缺失资产持续生成所需图片，不设每页生图次数上限；并发槽位只用于控制同时运行的任务数。
> 2. 低成本：优先使用原生形状和已有图片，但复杂图形无法可靠重构时可以继续生成，不设固定生图次数上限；通过资产优先级和并发槽位控制成本与速度。

Do not silently choose the expensive mode. If the user says “按你的建议”, choose low-cost for drafts/batches and high-fidelity for a final/key slide, and state that assumption.

## Input normalization and analysis

1. Inspect the input PPTX before calling `editppt prepare`. Record slide count, canvas size, and per-slide object types.
2. A slide may contain one picture, many pictures, native objects, or a mixture. Never assume one picture per slide and never reject a usable deck because it has multiple picture objects.
3. For a single full-slide picture, `editppt prepare` may consume the PPTX directly. For multiple pictures, native objects, or uncertain extraction, render every slide once to a page PNG with the installed PowerPoint renderer, then prepare the page PNGs. The rendered page is the visual source of truth.
4. Use GPT multimodal inspection of each page PNG as the only default recognition step. GPT reads the final Chinese copy, identifies visible objects and unknown regions, classifies each object, and establishes source-pixel coordinates. Do not invoke OCR, ask for OCR tokens, or add an OCR dependency.
5. Skip automatic geometry/text hints by default: use `editppt prepare ... --no-text-hints`. Generate hints only when GPT explicitly needs a measurement aid, and label them as non-semantic geometry rather than text recognition.

## Concurrency and throughput

Use this pipeline; only final deck assembly is intentionally serial:

1. Normalize/render the deck once. Do not launch a separate full-deck renderer for every picture object.
2. Fan out one GPT multimodal analysis task per page. A page with many picture objects still receives one page-level visual analysis plus an object inventory, not one serial recognition call per object.
3. Fan out independent per-page asset tasks for source cropping, alpha cleanup, segmentation and image generation. Each task has a unique output path and an explicit dependency list.
4. Fan out page-local native PPTX build, render and validation after that page's required assets resolve.
5. Run `editppt run record` for each completed page and `editppt run finalize` once, in page order.

Operational rules:

- Prepare all rendered page PNGs in one command and set `--max-concurrent-pages` to the available worker limit (normally 4–6). Dispatch independent page workers concurrently; do not process a multi-page deck page-by-page in a serial loop.
- Within a page, treat each source picture or generated asset candidate as an independent task for cropping, alpha cleanup, segmentation, or asset generation. Run independent tasks concurrently when the host supports it. Batch compatible assets into a composite sheet when that preserves fidelity; when individual asset calls are needed, run them as separate concurrent jobs with unique outputs.
- Do not make asset generation a prerequisite for layout. GPT analysis, the coordinate manifest, native text/geometry construction, and validation can proceed while independent visual assets are pending; insert assets only after their paths are available.
- For a one-page deck, page-level concurrency is unavailable by definition, so use asset-level concurrency and deterministic build/QA parallelism to avoid a serial 40-minute page.
- Treat elapsed time as telemetry, not a quality or generation-count cutoff. Record target and actual durations, but do not terminate a valid generation merely because a target duration was exceeded. Continue independent pages and assets in parallel while a slow task is running.
- Retry only after changing the prompt, mask, crop, model, or backend, and only for the affected asset. There is no arbitrary per-page generation-count cap; stop only for repeated unchanged failures, an explicit user cancellation, or a backend/rate-limit condition, and record the reason.

## Model recommendation

The task is not solved by a single model. It needs four capabilities: multimodal image reading, structured reasoning and coordinate extraction, optional image generation/editing or segmentation, and a PPTX/Open XML builder plus renderer.

- High-fidelity default: use the strongest available multimodal reasoning model for analysis and orchestration (currently recommend GPT-5.6 Sol in Codex) plus GPT-Image-2.5 Sunburst for every complex raster asset that cannot be preserved or reconstructed locally. Prefer a composite asset sheet when it preserves fidelity; otherwise run independent asset calls concurrently and lock placement with source-pixel coordinates.
- Low-cost default: use GPT-5.6 Luna for extraction, planning, native shape construction and validation. Use no ImageGen when native reconstruction is acceptable; if complex visuals cannot be reconstructed acceptably, generate the required assets and keep those tasks concurrent.
- GPT-5.6 Terra is the balanced middle option when the user wants more reasoning headroom than Luna without the Sol cost.
- For an external deployment, Gemini’s current multimodal models are strong candidates for image understanding, object detection and segmentation, but still require an independent PPTX builder. Claude is suitable for visual analysis and code orchestration, but high-fidelity bitmap generation needs an external image backend unless the target host provides one.

Treat model names as configuration, not hard-coded truth; check the current catalog before recommending a model for a new deployment. See [references/model-selection.md](references/model-selection.md).

## Mode contracts

### High-fidelity

Preserve supplied picture objects or deterministic crops whenever they are visually adequate. Generate every missing or materially inaccurate complex asset needed to meet the selected fidelity target; do not impose a per-page generation cap. Prefer a composite asset sheet when it improves throughput, but split independent asset jobs and run them concurrently when possible. Keep all readable text native, and keep cards, rules, connectors and simple geometry native. Use a source-pixel coordinate manifest so generated assets do not control page layout. Log every ImageGen attempt, success, failure and retry.

Expected trade-off: higher visual similarity, more image layers, higher generation cost, and less editability for intricate raster illustrations.

### Low-cost

Use native PPTX objects first for cards, ribbons, tiers, lines, nodes, icons and text when the approximation is acceptable. Preserve or crop supplied visual regions before considering generation. If a complex visual cannot be reconstructed with acceptable fidelity, generate it even in low-cost mode; low-cost is a preference, not a hard generation cap. Prioritize high-impact assets, run independent generations concurrently, and disclose all remaining raster assets.

Expected trade-off: lower generation cost and greater structural editability, with lower fidelity for glow, illustration detail and gradients.

## Shared reconstruction rules

1. Start a new run directory for every user-requested conversion. Preserve the supplied source image or rendered page PNG. Do not reuse prior manifests, coordinates, generated assets, PPTX files or previews unless the user explicitly asks for continuation or asks to apply a historical reconstruction method.
2. Use `editppt prepare` and the image-to-editable-ppt workflow. For a single page, claim local reconstruction with `editppt run dispatch --local`; for multiple pages, use page workers concurrently. When preparing page images, pass `--no-text-hints` and an explicit `--max-concurrent-pages` value.
3. Use GPT's visual reading as the text and object analysis. There is no OCR stage. All text boxes, images and shapes need source-pixel coordinates in the manifest; GPT must mark uncertain text/object regions for review instead of silently substituting an OCR result.
4. Never use the complete source screenshot as a full-slide background underneath editable copies of its baked text. Use a clean base, native masking/geometry, or an explicitly disclosed local raster layer.
5. Prefer native PowerPoint text, lines, rectangles, rounded rectangles, polygons and paths. “Editable” does not mean every glow or complex illustration becomes vector; disclose every remaining image layer.
6. Build, render the PPTX, inspect the rendered image, run page validation, package-integrity checks and overflow checks, then finalize. Do not report success from JSON structure alone.

## Usage accounting

Create a page/run-local `imagegen-usage-log.json` before the first image call. Record:

- mode, source and `history_reused: false` when the user requested a fresh run;
- run start/end timestamps and elapsed seconds for normalization, GPT analysis, asset processing, page build/QA, and finalization;
- each ImageGen attempt with serial number, asset purpose, status, output path, retry flag and failure reason;
- exact attempts, successful outputs and retries;
- optional before/after Codex account usage snapshots, explicitly labeled as overall usage rather than image-only quota.

Local cropping, alpha cleanup, SVG/native drawing, PPTX building, rendering and validation do not count as ImageGen calls. If the host does not expose image-only credit units, report exact call count and separately report the coarse overall-usage delta; never convert one into the other.

## Output

Deliver the editable `.pptx`, a rendered preview, the usage log and validation report. State the selected mode, exact ImageGen count, elapsed time by stage, concurrency setting, remaining raster layers, and validation status. For model guidance and capability boundaries, read [references/model-selection.md](references/model-selection.md) when recommending or porting the skill.
