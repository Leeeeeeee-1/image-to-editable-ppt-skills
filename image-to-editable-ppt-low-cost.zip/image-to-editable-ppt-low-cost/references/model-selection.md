# Model requirements — low-cost package

## Capability contract

The deployment must provide:

1. A fast multimodal model that can inspect complete pages and crops, read Chinese, return structured JSON, locate objects in source pixels, classify native geometry versus visual assets, and mark uncertainty.
2. An image generation or editing backend available on demand for complex or high-impact regions that native reconstruction and source crops cannot reproduce acceptably.
3. A deterministic PPTX builder and renderer.
4. Page-level and asset-level concurrency.

OCR is outside this contract. Text and structure come from multimodal visual analysis; the bundled default command passes `--no-text-hints`.

## Recommended local profile

- Analysis/reasoning: GPT-5.6 Luna for ordinary pages; GPT-5.6 Terra or a stronger multimodal model for dense or ambiguous pages.
- Image backend: GPT-Image-2.5 Sunburst when a visual asset actually needs generation.
- Construction/rendering: the bundled `editppt` CLI and a PowerPoint-capable renderer.

This is a recommendation, not a vendor lock-in. Select by capability and latency in an external environment.

## Cost policy

Low-cost means native-first and adaptive. It does not mean “never call ImageGen” or “use a fixed maximum count”. If a page has many complex regions, the workflow may perform multiple independent generation jobs; concurrency reduces wall-clock time, while the usage log reports the real cost.

## External-model substitutions

Another strong vision-language model may perform analysis if its output is normalized to the repository manifest schema. Do not replace multimodal analysis with a text-only model or silently introduce an OCR dependency.

## Acceptance criteria

Validate text, hierarchy, position, geometry, crop, icon silhouette, color, overlap, and clipping. Record any material raster-only region and any deliberate quality/cost compromise in the final report.
