---
name: image-to-editable-ppt-low-cost
description: Rebuild image-based PowerPoint slides into editable PPTX with a native-first, cost-aware strategy, GPT multimodal analysis, adaptive visual-asset generation, and concurrent page and asset processing; no OCR.
---

# Image-to-editable PPT - low-cost mode

Use this skill when the result must be editable and visually coherent while minimizing unnecessary image-generation work. It still adapts to page complexity: low-cost is a preference, not a hard quality failure.

## Fixed mode

This package is already the low-cost mode. Do not ask the user to choose between high and low cost after this skill is selected. Confirm the source file and whether the run is new or a continuation, then proceed.

## Model requirements

- **Primary analysis:** a fast multimodal reasoning model with image input, reliable Chinese reading, structured output, object bounds, object classification, and unknown-region marking. The current local recommendation is GPT-5.6 Luna; use GPT-5.6 Terra or a stronger model when a page is unusually dense or ambiguous.
- **Visual asset generation/editing:** an image model available on demand for complex regions that native shapes or source-faithful crops cannot reproduce acceptably. The current local recommendation is GPT-Image-2.5 Sunburst when available.
- **PPTX construction:** the bundled deterministic `editppt`/Open XML builder plus a PowerPoint-capable renderer for visual QA.
- **Not used:** OCR services, OCR tokens, or an OCR dependency. GPT vision is the source of text and visual structure information.

Model names are recommendations, not hard-coded API dependencies. In another environment, substitute models by capability rather than by brand.

## Required decision order

1. Inspect the source and render pages only when needed for reliable analysis or validation. Support a single picture or many picture objects on a page.
2. Run GPT multimodal page analysis and record text, geometry, visual assets, coordinates, confidence, and unknown regions.
3. Prefer native editable text, cards, ribbons, rules, connectors, simple icons, and basic fills.
4. Prefer a source crop or deterministic cleanup for a visual region when it is already faithful and cheaper than generation.
5. Call image generation for a complex or high-impact region only when native reconstruction and a source crop are not visually acceptable. There is no fixed ImageGen count cap; quality blockers may justify more calls, but unnecessary calls should be avoided.
6. Prioritize the largest visual errors first. Do not silently replace a material region with a crude approximation just to save a call.
7. Never leave a complete baked source screenshot underneath duplicate editable text.

## Concurrency and speed

- Normalize/render once, then run independent page analyses concurrently.
- Run independent crop, alpha, segmentation, and generation tasks concurrently with unique output paths and explicit dependencies.
- Build, render, and validate completed pages concurrently; assemble final pages in order.
- `editppt prepare ... --no-text-hints --max-concurrent-pages N` controls page workers; it is not a total ImageGen limit.
- For a one-page deck, use asset-level concurrency. Page-level concurrency cannot make one page parallel by itself.
- Continue independent work while a slow task runs. Stop retries only for unchanged repeated failures, backend/rate limits, or user cancellation.

## Validation and handoff

Require a final PPTX, preview render, usage log with actual ImageGen count and elapsed time, validation report, and asset provenance. Read these references when needed:

- [page-decision-tree.md](references/page-decision-tree.md) for native/crop/generation decisions.
- [manifest-schema.md](references/manifest-schema.md) for inventories and provenance.
- [cli-helper.md](references/cli-helper.md) for the bundled CLI workflow.
- [model-selection.md](references/model-selection.md) for model capability requirements and substitutions.

Report which regions remain raster-only. Do not claim full editability when material visual regions are still images.
