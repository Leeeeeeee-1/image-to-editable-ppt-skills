# Image-to-editable PPT — low cost

This is an independent Codex skill package for rebuilding image-based slides into editable PPTX with a native-first, cost-aware strategy.

## What it does

- Uses GPT multimodal vision to identify text, layout, icons, cards, connectors, illustrations, and unknown regions.
- Recreates text and simple geometry as native editable PowerPoint objects first.
- Uses source-faithful crops or deterministic cleanup before generating complex visual assets.
- Supports pages containing one picture or many picture objects.
- Processes independent pages and independent visual assets concurrently.
- Records actual image-generation attempts, retries, outputs, and elapsed time.

## Model requirements

Use a fast multimodal reasoning model for analysis and Chinese text reading. The current local recommendation is GPT-5.6 Luna, with GPT-5.6 Terra or a stronger model for dense pages. Use an image-generation/editing model only when native reconstruction and a source crop are not visually acceptable; GPT-Image-2.5 Sunburst is the current local recommendation when available. The bundled deterministic `editppt` builder and a PowerPoint-capable renderer are also required.

This mode does not use OCR. It has no fixed ImageGen count cap: the policy is native-first and adaptive, not an artificial limit that would fail on complex pages.

## Install

Copy this directory to the Codex skills directory, for example:

`%USERPROFILE%\\.codex\\skills\\image-to-editable-ppt-low-cost`

Then validate it with the bundled `quick_validate.py` from the Codex skill-creator package.

## Cost and speed

This mode reduces unnecessary generation by prioritizing native geometry and faithful source crops. Concurrency remains enabled: a one-page deck uses asset-level parallelism because page-level workers cannot parallelize a single page.

## Output contract

The run should deliver an editable PPTX, preview render, validation report, usage log, and asset provenance. “Editable” means native text and reconstructed geometry are editable; any intentionally retained raster region must be disclosed.
