# Image-to-editable PPT — high fidelity

This is an independent Codex skill package for rebuilding image-based slides into editable PPTX with maximum practical visual fidelity.

## What it does

- Uses GPT multimodal vision to identify text, layout, icons, cards, connectors, illustrations, and unknown regions.
- Recreates readable text and simple geometry as editable PowerPoint objects.
- Preserves source-faithful crops or generates complex visual assets when native reconstruction would visibly diverge.
- Supports pages containing one picture or many picture objects.
- Processes independent pages and independent visual assets concurrently.
- Records actual image-generation attempts, retries, outputs, and elapsed time.

## Model requirements

Use a strong multimodal reasoning model for analysis and Chinese text reading. The current local recommendation is GPT-5.6 Sol when available. Use a high-quality image generation/editing model for material visual assets; the current recommendation is GPT-Image-2.5 Sunburst when available. The bundled deterministic `editppt` builder and a PowerPoint-capable renderer are also required.

This mode does not use OCR. It also does not impose a fixed ImageGen count cap: material assets may be generated as needed, subject to backend limits, user cancellation, and retry stopping conditions.

## Install

Copy this directory to the Codex skills directory, for example:

`%USERPROFILE%\\.codex\\skills\\image-to-editable-ppt-high-fidelity`

Then validate it with the bundled `quick_validate.py` from the Codex skill-creator package.

## Cost and speed

This mode prioritizes fidelity over generation cost. A one-page deck still uses asset-level concurrency; `--max-concurrent-pages` cannot create multiple page workers when there is only one page.

## Output contract

The run should deliver an editable PPTX, preview render, validation report, usage log, and asset provenance. “Editable” means native text and reconstructed geometry are editable; any intentionally retained raster region must be disclosed.
