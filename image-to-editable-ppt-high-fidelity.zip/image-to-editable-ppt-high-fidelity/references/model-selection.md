# Model requirements — high-fidelity package

## Capability contract

The workflow is capability-based. A deployment must provide:

1. A multimodal model that can inspect the complete page and cropped regions, read Chinese reliably, return structured JSON, estimate source-pixel bounds, classify native geometry versus visual assets, and mark uncertainty instead of inventing details.
2. An image generation or image editing backend that can accept a reference image or mask and produce a visually faithful, preferably text-free or transparent asset.
3. A deterministic PPTX builder and a renderer for page-level visual comparison.
4. A concurrency mechanism for independent page and asset jobs.

OCR is outside this contract. Text and structure come from multimodal visual analysis; the bundled default command passes `--no-text-hints`.

## Recommended local profile

- Analysis/reasoning: the strongest available GPT multimodal reasoning model; the current recommendation is GPT-5.6 Sol when available.
- Image backend: the highest-quality available GPT image generation/editing model; the current recommendation is GPT-Image-2.5 Sunburst when available.
- Construction/rendering: the bundled `editppt` CLI and a PowerPoint-capable renderer.

These names are replaceable. The requirement is quality and multimodal capability, not a specific vendor endpoint.

## External-model substitutions

An external deployment can use another strong vision-language model for analysis and another image backend for complex assets, provided the analysis output is normalized to the repository manifest schema. Do not substitute a text-only model for page analysis. Do not use a generic OCR pipeline as a silent replacement.

## Fidelity acceptance

Before delivery, compare the rendered result with the source at page level and at material-asset level. Check text content, hierarchy, position, crop, icon silhouette, card/ribbon geometry, color, overlap, and clipping. Any unresolved visual region must be listed in provenance and in the final report.
