---
name: image-to-editable-ppt-high-fidelity
description: Rebuild image-based PowerPoint slides into editable PPTX with high visual fidelity using GPT multimodal analysis, source-pixel coordinates, adaptive visual-asset generation, and concurrent page and asset processing; no OCR.
---

# Image-to-editable PPT - high-fidelity mode

Use this skill when the source is a screenshot, scanned slide, raster-only PPTX, or PDF page and the result must remain visually close while text, layout geometry, icons, and selected visual assets are independently editable.

## Fixed mode

This package is already the high-fidelity mode. Do not ask the user to choose between high and low cost after this skill is selected. Confirm the source file and whether the run is new or a continuation, then proceed.

## Model requirements

- **Primary analysis:** a strong multimodal reasoning model with image input, reliable Chinese reading, structured output, object classification, unknown-region marking, and source-pixel coordinate extraction. The current local recommendation is the strongest available GPT multimodal reasoning model; GPT-5.6 Sol is the preferred profile when available.
- **Visual asset generation/editing:** a high-quality image model that accepts source references or masks and can create text-free or transparent assets when needed. The current local recommendation is GPT-Image-2.5 Sunburst when available.
- **PPTX construction:** the bundled deterministic `editppt`/Open XML builder plus a PowerPoint-capable renderer for visual QA.
- **Not used:** OCR services, OCR tokens, or an OCR dependency. GPT vision is the source of text and visual structure information.

Model names are recommendations, not hard-coded API dependencies. In another environment, substitute models by capability rather than by brand.

## Required workflow

1. Inspect the source PPTX/PDF/image, slide count, canvas, object types, and whether each page contains one or many picture objects.
2. Render each page once when the source has multiple pictures, uncertain extraction, or raster-only content. Do not reject a usable deck because a page has several image objects.
3. Run one GPT multimodal page analysis per page. The analysis must return a visual inventory, readable text inventory, object bounds in source pixels, editability classification, and explicitly marked unknown regions.
4. Rebuild readable text, cards, rules, connectors, ribbons, and simple geometry as native PPTX objects. Preserve supplied image objects and crops when they are visually adequate.
5. Generate every materially missing or inaccurate complex visual asset required by the fidelity target. There is no per-page ImageGen count cap in this mode. Use composite sheets only when they preserve fidelity; otherwise create separate asset jobs.
6. Never leave a complete baked source screenshot underneath duplicate editable text. A source crop may be retained only for a reviewed visual region that is intentionally not reconstructed.
7. Log every generation attempt, retry, failure, output path, and elapsed time. A failure should trigger a changed crop, mask, prompt, model, or backend attempt when the asset is material.

## Concurrency and speed

- Normalize/render once, then run independent page analyses concurrently.
- Run independent crop, alpha, segmentation, and generation tasks concurrently with unique output paths and explicit dependencies.
- Build, render, and validate completed pages concurrently; assemble final pages in order.
- `editppt prepare ... --no-text-hints --max-concurrent-pages N` controls page workers. It is not a total ImageGen limit.
- For a one-page deck, use asset-level concurrency; do not serialize independent icons and illustrations.
- Continue independent tasks while a slow generation runs. Elapsed-time targets are telemetry, not quality cutoffs.

## Validation and handoff

Require a final PPTX, rendered preview, usage log with actual ImageGen count and elapsed time, validation report, and asset provenance. Read these references when the current task needs them:

- [page-decision-tree.md](references/page-decision-tree.md) for native-versus-image decisions.
- [manifest-schema.md](references/manifest-schema.md) for inventories and provenance.
- [cli-helper.md](references/cli-helper.md) for the bundled CLI workflow.
- [model-selection.md](references/model-selection.md) for model capability requirements and substitutions.

Do not claim that a page is fully editable when any material visual region remains raster-only; report that boundary explicitly.
